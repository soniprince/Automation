#from behave import *
from selenium.webdriver import Chrome

#@given(u'User opens Google Chrome browser')
def step_impl():
    path='C:\\chromedriver.exe'
    driver=Chrome(executable_path=path)
    driver.get("http://www.phptravels.net")
    driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/a[1]').click()
    driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/ul[1]/li[1]/a[1]').click()
    print(driver.title)

    assert driver.title == "Login"