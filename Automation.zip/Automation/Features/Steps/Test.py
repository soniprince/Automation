#from behave import *
from selenium.webdriver import Chrome

#@given(u'User opens Google Chrome browser')
def step_impl():
    path="C:\\chromedriver.exe"
    driver=Chrome(executable_path=path)
    driver.get("http://www.phptravels.net")
    print("great")

