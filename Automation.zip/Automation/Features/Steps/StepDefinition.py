from behave import *
from selenium.webdriver import Chrome

@given(u'User opens Google Chrome browser')
def step_impl(context):
    path='C:\\chromedriver.exe'
    context.driver=Chrome(executable_path=path)

@given(u'User enters url in the Google Chrome browser')
def step_impl(context):
    context.driver.get("http://www.phptravels.net")
    #context.driver.maximize_window()

@when(u'User clicks on MY ACCOUNT button')
def step_impl(context):
    context.driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/a[1]').click()

@when(u'Click on Login')
def step_impl(context):
    context.driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/ul[1]/li[1]/a[1]').click()

@when(u'User enters Email {Email}')
def step_impl(context, Email):
    context.driver.find_element_by_xpath('//input[@placeholder="Email"]').send_keys(Email)


@when(u'User enters Password {Password}')
def step_impl(context, Password):
    context.driver.find_element_by_xpath('//input[@placeholder="Password"]').send_keys(Password)

@when(u'Click on Login button')
def step_impl(context):
    context.driver.find_element_by_xpath('//button[contains(text(),"Login")]').click()
    context.driver.refresh()

@then(u'User should logged in successfully')
def step_impl(context):
    print(context.driver.title)
    context.driver.refresh()
    assert context.driver.title == "My Account"

@then(u'User should see his account page')
def step_impl(context):
    assert context.driver.current_url == "https://www.phptravels.net/account"

#from behave import *
#from selenium.webdriver import Chrome

@given(u'User is logged in on the website')
def step_impl(context):
    path = 'C:\\chromedriver.exe'
    context.driver = Chrome(executable_path=path)
    context.driver.get("http://www.phptravels.net")
    context.driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/a[1]').click()
    context.driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/ul[1]/li[1]/a[1]').click()
    context.driver.find_element_by_xpath('//input[@placeholder="Email"]').send_keys("user@phptravels.com")
    context.driver.find_element_by_xpath('//input[@placeholder="Password"]').send_keys("demouser")
    context.driver.find_element_by_xpath('//button[contains(text(),"Login")]').click()
    context.driver.maximize_window()

@when(u'User clicks on Hotels')
def step_impl(context):
    context.driver.find_element_by_xpath('//ul[@class="nav navbar-nav go-right"]//li[2]//a[1]').click()
    context.driver.implicitly_wait(10)
    context.driver.refresh()

@when(u'Enters name of city')
def step_impl(context):
    context.driver.find_element_by_xpath('//span[contains(text(),"Search by Hotel")]').click()
    context.driver.find_element_by_xpath('//div[@id="select2-drop"]//input[@type="text"]').send_keys("montrea")
    context.driver.implicitly_wait(10)
    context.driver.find_element_by_xpath('//span[@class="select2-match"]').click()

@when(u'User enters Check in date')
def step_impl(context):
    context.driver.find_element_by_xpath('//div[@id="dpd1"]//input[@placeholder="Check in"]').click()
    context.driver.find_element_by_xpath('// div[9] // div[1] // table[1] // tbody[1] // tr[5] // td[6]').click()

@when(u'User enters Check out date')
def step_impl(context):
    #context.driver.find_element_by_xpath('//input[@placeholder="Check out"]').click()
    context.driver.find_element_by_xpath('//div[10]//div[1]//table[1]//tbody[1]//tr[6]//td[3]').click()

@when(u'User enters family size')
def step_impl(context):
    context.driver.find_element_by_xpath('//input[@id="travellersInput"]').click()
    context.driver.implicitly_wait(10)
    context.driver.find_element_by_xpath('//div[contains(@class,"row")]//div[contains(@class,"row")]//div[1]//div[1]//div[2]//div[1]//div[1]//span[2]').click()
    context.driver.find_element_by_xpath('//div[contains(@class,"row")]//div[contains(@class,"row")]//div[2]//div[1]//div[2]//div[1]//div[1]//span[2]').click()

@when(u'User clicks on Search')
def step_impl(context):
    context.driver.find_element_by_xpath('//form[@name="fCustomHotelSearch"]//button[@type="submit"]').click()

@then(u'User should see results of hotels')
def step_impl(context):
    assert context.driver.title == "Search Results"