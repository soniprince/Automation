from behave import *
from selenium.webdriver import Chrome
import pytest

@given(u'User is logged in on the website')
def test_step_impl():
    global driver
    path = 'C:\\chromedriver.exe'
    driver = Chrome(executable_path=path)
    driver.get("http://www.phptravels.net")
    driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/a[1]').click()
    driver.find_element_by_xpath('/html[1]/body[1]/nav[1]/div[1]/div[2]/ul[2]/ul[1]/li[1]/ul[1]/li[1]/a[1]').click()
    driver.find_element_by_xpath('//input[@placeholder="Email"]').send_keys("user@phptravels.com")
    driver.find_element_by_xpath('//input[@placeholder="Password"]').send_keys("demouser")
    driver.find_element_by_xpath('//button[contains(text(),"Login")]').click()
    driver.maximize_window()

@when(u'User clicks on Hotels')
def test_step_imp2():
    driver.find_element_by_xpath('//ul[@class="nav navbar-nav go-right"]//li[2]//a[1]').click()
    driver.implicitly_wait(10)
    driver.refresh()

@when(u'Enters name of city')
def test_step_imp3():
    driver.find_element_by_xpath('//span[contains(text(),"Search by Hotel")]').click()
    driver.find_element_by_xpath('//div[@id="select2-drop"]//input[@type="text"]').send_keys("montrea")
    driver.implicitly_wait(10)
    driver.find_element_by_xpath('//span[@class="select2-match"]').click()

@when(u'User enters Check in date')
def test_step_imp4():
    driver.find_element_by_xpath('//div[@id="dpd1"]//input[@placeholder="Check in"]').click()
    driver.find_element_by_xpath('// div[9] // div[1] // table[1] // tbody[1] // tr[5] // td[6]').click()

@when(u'User enters Check out date')
def test_step_imp5():
    #context.driver.find_element_by_xpath('//input[@placeholder="Check out"]').click()
    driver.find_element_by_xpath('//div[10]//div[1]//table[1]//tbody[1]//tr[6]//td[3]').click()
@when(u'User enters family size')
def test_step_imp6():
    driver.find_element_by_xpath('//input[@id="travellersInput"]').click()
    driver.implicitly_wait(10)
    driver.find_element_by_xpath('//div[contains(@class,"row")]//div[contains(@class,"row")]//div[1]//div[1]//div[2]//div[1]//div[1]//span[2]').click()
    driver.find_element_by_xpath('//div[contains(@class,"row")]//div[contains(@class,"row")]//div[2]//div[1]//div[2]//div[1]//div[1]//span[2]').click()
    driver.find_element_by_xpath('//form[@name="fCustomHotelSearch"]//button[@type="submit"]').click()
    assert driver.title == "Search Results"